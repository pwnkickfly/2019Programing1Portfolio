class Store:
	def __init__(self, word, definition):
		self.word=word
		self.deff=definition
		self.out=open('output.txt', 'a')
	def save(self):
		self.out.write(self.word + '\n')
		self.out.write(self.deff + '\n\n')
		self.out.close()
