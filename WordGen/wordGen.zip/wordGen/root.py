# Gabe Wong 12019 H.E.
import random as r
class Root:
	def __init__(self):
		self.roots = ['anthro', 'stereo', 'calc', 'cide', 'domin', 'equ', 'flect', 'gyn', 'mania', 'xeno', 'ped', 'sect']
		self.defin = ['humans', 'strength', 'stone', 'killing', 'mastering', 'equalling', 'bending', 'woman', 'madness', 'foreign', 'children', 'cutting']
	def choose(self):
		self.choice=r.randint(0, len(self.roots)-1)
		return [self.roots[self.choice], self.defin[self.choice]]
