#Daniel Wong 2019
import random as r
class Prefix:
    def __init__(self):
        self.pre = ['homo', 'trans','neo','hemi','anti','retro','sub','intro','para','ex','abs','super']
        self.defin = ['being the same','being across','being new','being half','being against','being backward','being beneath','being within','being beside','being outside','being away from','being above']
    def pick(self):
        self.words = r.randint(0,len(self.pre)-1)
        return [self.pre[self.words],self.defin[self.words]]
