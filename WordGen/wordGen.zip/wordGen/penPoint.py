# Anthony Liu
from root import Root
from prefix import Prefix
from suffix import Suffix
from store import Store
import random as r
print ('Welcome to Randomized Word Generation')
word = ''
deff = ''

while True:
    print ('Pick Your Poison:')
    print ('1. Automatic Word Generator')
    print ('2. Use Own Root')
    print ('3. Return to the Shadow Realm')

    choice = input('')

    if choice == '1':
        print('You chose the Automatic Word Generator')
        rt = Root()
        mid = rt.choose()
        pre = Prefix()
        frst = pre.pick()
        suf = Suffix()
        last = suf.pick()

        print ('')
        print ('Your Word is ') + frst[0] + mid[0] + last[0]
        print ('Your Definition is: ') + last[1] + ' ' + frst[1] + ' ' + mid[1]
        print ('')

        word = frst[0] + mid[0] + last[0]
        deff = last[1] + ' ' + frst[1] + ' ' + mid[1]
    elif choice == '2':
        print('You Chose to Use Your Own Root')
        pre = Prefix()
        frst = pre.pick()
        suf = Suffix()
        last = suf.pick()
        root = input('What is Your Root? ')
        defin = input('What is the Definition of Your Root ')

        print (' ')
        print ('Your Word is ') + frst[0] + root + last[0]
        print ('Your Word is ') + last[1] + ' ' + frst[1] + ' ' + defin
        print (' ')
        word = frst[0] + root + last[0]
        deff = last[1] + ' ' + frst[1] + ' ' + defin
    elif choice == '3':
        break
    else:
        print ('Please Input A Number')
    st = Store(word, deff)

    choose = input('Would you like to save? (Y/N): ')

    if  choose == 'y' or choose == 'Y':
        st.save()
        print ('Saved')
        print ('')
