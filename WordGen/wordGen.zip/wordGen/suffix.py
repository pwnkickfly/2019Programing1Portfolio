#Daniel Wong 2019
import random as r
class Suffix:
    def __init__(self):
        self.suf = ['able','acity','ation','cracy','alholic','al','ible','oid','phile','ology','ization','ly']
        self.defin = ['able to be','quality of','action or process of','a government','one with an obsession for','relating to','able to be','resembling','one who loves','science of','act or process of','in the manner of']
    def pick(self):
        self.words = r.randint(0,len(self.suf)-1)
        return [self.suf[self.words],self.defin[self.words]]
